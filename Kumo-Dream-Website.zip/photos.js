document.querySelectorAll('[data-slot]').forEach(slot => {
 const image = slot.querySelector('img'), placeholder = slot.querySelector('.empty-photo');
 const show = () => { image.hidden = false; placeholder.hidden = true; };
 const hide = () => { image.hidden = true; placeholder.hidden = false; };
 image.addEventListener('load', show); image.addEventListener('error', hide);
 if (image.complete && image.naturalWidth > 0) show();
});
