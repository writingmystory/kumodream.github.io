# Kumo Dream — GitHub Pages website

Your portable portfolio includes your latest design, story, location, Instagram, and Gmail contact button. The visible email address remains removed; the button still uses it as the recipient.

## Publish

1. Extract this ZIP on your computer.
2. Add your JPG photos to the images folder (see below).
3. Double-click index.html to preview your website.
4. Open your public GitHub repository. Select Add file → Upload files.
5. Upload this folder's CONTENTS, including the images folder. Do not upload the ZIP or nest index.html inside an outer folder.
6. Click Commit changes.
7. Open Settings → Pages. Choose Deploy from a branch, main, and / (root). Click Save.
8. Wait for publishing and open the link shown in Pages settings.

If your repository is YOURUSERNAME.github.io, your address is https://YOURUSERNAME.github.io/. Relative asset paths also support project repositories.

## Photos

Photo files are not included in this export. Empty beige frames remain until you add your images:

- images/cover.jpg: wide cover image
- images/photo1.jpg: first gallery photo
- images/photo2.jpg: second gallery photo
- images/photo3.jpg: third gallery photo

Use exact lowercase filenames and actual JPEG exports. The wide cover may crop the edges; gallery images show the full photo. To replace a photo, upload a JPG with the same name into the repository's images folder and commit changes. Refresh after GitHub finishes publishing.

## Files and editing

- index.html: text, photo references, and links
- styles.css: colors, fonts, spacing, and layout; later rules override earlier rules
- photos.js: shows local photos and handles missing images
- .nojekyll: tells GitHub to serve the files directly

No build command, server, or ChatGPT subscription is needed for this static version. Google Fonts requires internet access; fallback fonts are provided.

The click-to-upload editor and ChatGPT sign-in have been removed for GitHub Pages. Photos are managed through your repository and do not sync with the original site.

Your current hosted Site has not been changed or taken down by this export.
